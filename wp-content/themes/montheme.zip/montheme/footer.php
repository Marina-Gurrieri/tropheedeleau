</div>
<footer>
	<div class="row row-container">
		<div class="medium-4 columns">
			Le Lorem Ipsum est simplement du faux texte employé dans la composition et la mise en page avant impression. Le Lorem Ipsum est le faux texte standard de l'imprimerie depuis les années 1500, quand un peintre anonyme assembla ensemble des morceaux de texte pour réaliser un livre spécimen de polices de texte. Il n'a pas fait que survivre cinq siècles, mais s'est aussi adapté à la bureautique informatique, sans que son contenu n'en soit modifié.
		</div>
		<div class="medium-4 columns">
			<ul>
				<li><a href="#">Le concours</a></li>
				<li><a href="#">Règlements</a></li>
				<li><a href="#">Dossier d'inscription</a></li>
				<li><a href="#">Calendrier</a></li>
				<li><a href="#">Contacts</a></li>
				<li><a href="#">Editions précédentes</a></li>
			</ul>
		</div>
		<div class="medium-4 columns">
			<img src="http://placehold.it/215x90">
		</div>
	</div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
